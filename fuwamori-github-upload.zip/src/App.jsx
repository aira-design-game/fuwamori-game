import React, { useEffect, useMemo, useRef, useState } from 'react';

const W = 390;
const H = 690;
const PETAL_COUNT = 12;

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

function makePetals() {
  const positions = [
    [45, 110], [125, 92], [225, 116], [325, 98],
    [75, 205], [170, 185], [275, 215], [345, 190],
    [50, 325], [145, 300], [245, 345], [330, 315]
  ];
  return positions.map(([x, y], i) => ({
    id: i,
    x, y,
    collected: false,
    delay: (i * 0.17) % 1.2
  }));
}

function App() {
  const [started, setStarted] = useState(false);
  const [won, setWon] = useState(false);
  const [petals, setPetals] = useState(makePetals);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [time, setTime] = useState(35);
  const [message, setMessage] = useState('花びらを12枚あつめよう');
  const [player, setPlayer] = useState({ x: 195, y: 560, targetX: 195, targetY: 560 });
  const [sparkles, setSparkles] = useState([]);
  const fieldRef = useRef(null);

  const remaining = PETAL_COUNT - score;

  useEffect(() => {
    if (!started || won) return;
    const timer = setInterval(() => {
      setTime(t => {
        if (t <= 1) {
          clearInterval(timer);
          setWon(false);
          setStarted(false);
          setMessage('もう一回、ふわっとおさんぽしよう');
          return 35;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [started, won]);

  useEffect(() => {
    if (!started || won) return;
    let raf;
    const tick = () => {
      setPlayer(p => {
        const dx = p.targetX - p.x;
        const dy = p.targetY - p.y;
        const d = Math.hypot(dx, dy);
        if (d < 1.5) return p;
        const step = Math.min(5.5, d);
        return { ...p, x: p.x + dx / d * step, y: p.y + dy / d * step };
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, won]);

  useEffect(() => {
    if (!started || won) return;
    const hit = petals.find(p => !p.collected && dist(player, p) < 40);
    if (hit) {
      setPetals(ps => ps.map(p => p.id === hit.id ? { ...p, collected: true } : p));
      setScore(s => {
        const next = s + 1;
        if (next >= PETAL_COUNT) {
          setWon(true);
          setMessage('ぜんぶ集めた！ ふわもりの森が元気になったよ');
        } else {
          setMessage(next % 3 === 0 ? 'いいね！ もっとふわっと♪' : 'きらきらゲット！');
        }
        return next;
      });
      setCombo(c => c + 1);
      setSparkles(sp => [...sp, { id: crypto.randomUUID(), x: hit.x, y: hit.y }]);
      setTimeout(() => setSparkles(sp => sp.slice(1)), 550);
    }
  }, [player, petals, started, won]);

  const reset = () => {
    setPetals(makePetals());
    setScore(0);
    setCombo(0);
    setTime(35);
    setWon(false);
    setStarted(true);
    setMessage('花びらを12枚あつめよう');
    setPlayer({ x: 195, y: 560, targetX: 195, targetY: 560 });
    setSparkles([]);
  };

  const handlePointer = (e) => {
    if (!started || won) return;
    const rect = fieldRef.current.getBoundingClientRect();
    const x = clamp(((e.clientX - rect.left) / rect.width) * W, 20, W - 20);
    const y = clamp(((e.clientY - rect.top) / rect.height) * H, 80, H - 35);
    setPlayer(p => ({ ...p, targetX: x, targetY: y }));
  };

  const pct = (time / 35) * 100;

  return (
    <main className="app">
      <div className="phone">
        <header className="topbar">
          <div>
            <div className="brand">ふわもりさんぽ</div>
            <div className="subtitle">ふわっと集めて、こころを満たそう</div>
          </div>
          <div className="timer">
            <span>TIME</span>
            <b>{String(time).padStart(2, '0')}</b>
          </div>
        </header>

        <section className="status">
          <div className="scorebox">
            <span>ひろった花びら</span>
            <strong>{score}<small> / {PETAL_COUNT}</small></strong>
          </div>
          <div className="progress"><i style={{width: `${(score / PETAL_COUNT) * 100}%`}} /></div>
        </section>

        <div className="message">{message}</div>

        <section
          ref={fieldRef}
          className="field"
          onPointerDown={handlePointer}
          onPointerMove={(e) => { if (e.buttons === 1) handlePointer(e); }}
        >
          <div className="sun-glow" />
          <div className="cloud cloud-a" />
          <div className="cloud cloud-b" />
          <div className="hill hill-back" />
          <div className="hill hill-front" />

          {Array.from({length: 13}).map((_, i) => (
            <span key={i} className="grass" style={{
              left: `${12 + (i * 31) % 94}%`,
              bottom: `${16 + (i * 19) % 17}%`,
              transform: `rotate(${(i % 2 ? 1 : -1) * (8 + i % 5 * 4)}deg)`
            }} />
          ))}

          {petals.map(p => !p.collected && (
            <button
              key={p.id}
              className="petal"
              style={{ left: `${p.x}px`, top: `${p.y}px`, animationDelay: `${p.delay}s` }}
              aria-label="花びら"
              onPointerDown={(e) => { e.stopPropagation(); handlePointer(e); }}
            >
              <span />
            </button>
          ))}

          {sparkles.map(s => (
            <div key={s.id} className="sparkle" style={{left: s.x, top: s.y}}>
              <i /><i /><i /><i />
            </div>
          ))}

          <div
            className={`character ${won ? 'happy' : ''}`}
            style={{ left: `${player.x}px`, top: `${player.y}px` }}
          >
            <img src="/character.png" alt="ふわもりのキャラクター" />
            <div className="shadow" />
          </div>

          {!started && !won && (
            <div className="start-panel">
              <div className="mini-character"><img src="/character.png" alt="" /></div>
              <h1>ふわもりさんぽ</h1>
              <p>画面をタップして移動。<br/>花びらを12枚集めて、森を元気にしよう。</p>
              <button className="start-btn" onPointerDown={(e) => {e.stopPropagation(); reset();}}>
                さんぽをはじめる
              </button>
            </div>
          )}

          {won && (
            <div className="result-panel">
              <div className="result-icon">✦</div>
              <h2>ふわっと大成功！</h2>
              <p>12枚の花びらを集めました。</p>
              <div className="result-score">SCORE <b>{score * 100 + time * 10}</b></div>
              <button className="start-btn" onPointerDown={(e) => {e.stopPropagation(); reset();}}>
                もう一度あそぶ
              </button>
            </div>
          )}
        </section>

        <footer className="hint">
          <span className="dot" />
          <span>{started && !won ? 'タップした場所へ、ふわっと移動します' : 'スマホの縦画面で遊べます'}</span>
        </footer>
      </div>
    </main>
  );
}

export default App;
